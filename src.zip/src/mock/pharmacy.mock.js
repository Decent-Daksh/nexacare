/* Pharmacy shape: { stock[], alerts[], reorderQueue[] } */
const STOCK = [
  { id: 'M-001', name: 'Metformin 500mg', sku: 'MET500', stock: 240, reorderLevel: 100, expiry: '2027-02-15', batch: 'B2401', supplier: 'Sun Pharma', price: 1.20 },
  { id: 'M-002', name: 'Atorvastatin 10mg', sku: 'ATV010', stock: 38,  reorderLevel: 80,  expiry: '2026-08-30', batch: 'A2310', supplier: 'Cipla',     price: 2.50 },
  { id: 'M-003', name: 'Amlodipine 5mg',   sku: 'AML005', stock: 412, reorderLevel: 120, expiry: '2027-05-12', batch: 'A2412', supplier: 'Lupin',     price: 1.80 },
  { id: 'M-004', name: 'Amoxicillin 500mg',sku: 'AMX500', stock: 12,  reorderLevel: 60,  expiry: '2026-06-10', batch: 'X2306', supplier: 'Mankind',   price: 4.20 },
  { id: 'M-005', name: 'Pantoprazole 40mg',sku: 'PAN040', stock: 180, reorderLevel: 80,  expiry: '2026-05-20', batch: 'P2305', supplier: 'Dr Reddy', price: 3.10 },
  { id: 'M-006', name: 'Salbutamol Inhaler', sku: 'SAL100', stock: 22, reorderLevel: 30, expiry: '2027-01-15', batch: 'S2501', supplier: 'Cipla',  price: 145.00 },
  { id: 'M-007', name: 'Insulin Glargine', sku: 'INS100', stock: 9,   reorderLevel: 20,  expiry: '2026-07-30', batch: 'I2407', supplier: 'Sanofi',    price: 480.00 },
  { id: 'M-008', name: 'Paracetamol 650mg',sku: 'PCM650', stock: 980, reorderLevel: 200, expiry: '2027-09-02', batch: 'P2509', supplier: 'GSK',       price: 0.90 },
];

export const mockPharmacy = () => ({
  stock: STOCK,
  alerts: [
    { id: 'AL-1', kind: 'Low Stock', drug: 'Amoxicillin 500mg', detail: '12 units (reorder at 60)' },
    { id: 'AL-2', kind: 'Expiring',  drug: 'Pantoprazole 40mg', detail: 'Expires in 16 days' },
    { id: 'AL-3', kind: 'Low Stock', drug: 'Insulin Glargine',  detail: '9 units (reorder at 20)' },
  ],
  reorderQueue: [
    { id: 'PO-501', drug: 'Amoxicillin 500mg', quantity: 200, supplier: 'Mankind', eta: '2026-05-07', status: 'Awaiting Approval' },
    { id: 'PO-502', drug: 'Insulin Glargine',  quantity: 30,  supplier: 'Sanofi',  eta: '2026-05-09', status: 'Approved' },
    { id: 'PO-503', drug: 'Atorvastatin 10mg', quantity: 150, supplier: 'Cipla',   eta: '2026-05-10', status: 'Awaiting Approval' },
  ],
});
