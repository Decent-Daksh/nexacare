import { createContext, useContext, useState, useEffect } from 'react';

const AuthContext = createContext(null);

const mockUser = {
  id: 'U-001',
  name: 'Dr. Priya Sharma',
  role: 'admin', // Changed to lowercase for consistency
  clinic: { name: 'Sunrise Clinic', location: 'Dehradun', tier: 'Growth' },
  avatar: null,
};

export function AuthProvider({ children }) {
  // Initialize user state by checking localStorage for a persisted role first
  const [user, setUser] = useState(() => {
    const savedRole = localStorage.getItem('nexacare_role');
    if (savedRole) {
      return { ...mockUser, role: savedRole };
    }
    return mockUser;
  });
  
  const [token, setToken] = useState('mock-token');

  // Function to change the role and persist it
  const switchRole = (newRole) => {
    setUser(prev => {
      if (!prev) return null;
      const updatedUser = { ...prev, role: newRole };
      localStorage.setItem('nexacare_role', newRole);
      return updatedUser;
    });
  };

  const login = async () => { 
    const savedRole = localStorage.getItem('nexacare_role') || 'admin';
    setUser({ ...mockUser, role: savedRole }); 
    setToken('mock-token'); 
  };
  
  const logout = () => { 
    setUser(null); 
    setToken(null); 
    // We keep the role in localStorage so it remembers the preference for next login
  };

  return (
    <AuthContext.Provider value={{ 
      user, 
      token, 
      clinicInfo: mockUser.clinic, 
      login, 
      logout,
      switchRole // Exposed in the context value
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);