import { createRouter, useRouter, createRoute } from "@tanstack/react-router";
import { Route as rootRoute } from './routes/__root';

// 1. Import Components
import Dashboard from './pages/Dashboard';
import PatientHub from './pages/PatientHub';
import StaffCommand from './pages/StaffCommand';
import UnauthorizedPage from './pages/unauthorized';
import RoleManager from './pages/admin/RoleManager';
import LoginPage from './pages/Login';

// 2. Import RBAC Guard
import { ProtectedRoute } from './components/ProtectedRoute';

// 3. Global Error Component
function DefaultErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  const router = useRouter();
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <div className="mx-auto mb-6 flex h-16 w-16 items-center justify-center rounded-full bg-destructive/10">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-destructive" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126ZM12 15.75h.007v.008H12v-.008Z" />
          </svg>
        </div>
        <h1 className="text-2xl font-bold tracking-tight text-foreground">Something went wrong</h1>
        <p className="mt-2 text-sm text-muted-foreground">An unexpected error occurred. Please try again.</p>
        <div className="mt-6 flex items-center justify-center gap-3">
          <button onClick={() => { void router.invalidate(); reset(); }} className="rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground">Try again</button>
          <a href="/" className="rounded-md border border-input bg-background px-4 py-2 text-sm font-medium">Go home</a>
        </div>
      </div>
    </div>
  );
}

// 4. Define Routes
const loginRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/login',
  component: LoginPage,
});

const unauthorizedRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/unauthorized',
  component: UnauthorizedPage,
});

const indexRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/',
  component: Dashboard,
});

const patientHubRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/patients',
  component: () => (
    <ProtectedRoute allowedRoles={['admin', 'doctor']}>
      <PatientHub />
    </ProtectedRoute>
  ),
});

const staffCommandRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/staff',
  component: () => (
    <ProtectedRoute allowedRoles={['admin', 'manager']}>
      <StaffCommand />
    </ProtectedRoute>
  ),
});

const roleManagerRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/admin/roles',
  component: () => (
    <ProtectedRoute allowedRoles={['admin']}>
      <RoleManager />
    </ProtectedRoute>
  ),
});

// 5. Create Route Tree
const routeTree = rootRoute.addChildren([
  indexRoute,
  loginRoute,
  unauthorizedRoute,
  patientHubRoute,
  staffCommandRoute,
  roleManagerRoute,
]);

// 6. Create and Export Router
export const router = createRouter({
  routeTree,
  context: {},
  scrollRestoration: true,
  defaultPreload: 'intent',
  defaultErrorComponent: DefaultErrorComponent,
});

// 7. Register for Type Safety
declare module '@tanstack/react-router' {
  interface Register {
    router: typeof router;
  }
}